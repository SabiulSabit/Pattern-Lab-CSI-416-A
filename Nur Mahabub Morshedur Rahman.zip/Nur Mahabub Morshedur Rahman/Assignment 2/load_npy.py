import numpy as np
array_loaded = np.load('filePath')
print(array_loaded.shape)
print(array_loaded)